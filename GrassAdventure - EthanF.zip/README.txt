Author: Ethan Fowler

Description: This is a project I created for a highschool computer science class in 2019. It's a text-based adventure game played in the console.

Instructions:
	1. Extract the files
	2. Navigate to the directory in the command prompt
	3. Type "javac GrassAdventure.java" in the console
	4. Type "java GrassAdventure.java" in the console
	5. Enjoy!